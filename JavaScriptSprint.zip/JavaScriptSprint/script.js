console.log("JavaScript is linked and running!");

document.addEventListener("DOMContentLoaded", function() {
    fetch('data.json')
        .then(response => response.json())
        .then(data => {
            console.log(data);
            displayData(data);
        })
        .catch(error => console.error('Error loading the JSON data: ', error));
});

function displayData(jsonData) {
    const displayElement = document.getElementById('data-display');
    jsonData.forEach(item => {
        const content = document.createElement('p');
        content.textContent = `ID: ${item.id}, Name: ${item.name}`;
        displayElement.appendChild(content);
    });
}

function getTotalRecords(jsonData) {
    return `Total records: ${jsonData.length}`;
}

function listAllNames(jsonData) {
    return `Names: ${jsonData.map(item => item.name).join(', ')}`;
}

function listRoles(jsonData) {
    return `Roles: ${jsonData.map(item => item.role).join(', ')}`;
}

fetch('data.json')
    .then(response => response.json())
    .then(data => {
        console.log(getTotalRecords(data));
        console.log(listAllNames(data));
        console.log(listRoles(data));
        displayData(data);
    })
    .catch(error => console.error('Error:', error));
